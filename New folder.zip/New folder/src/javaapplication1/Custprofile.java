
package javaapplication1;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author MalwarE
 */
public class Custprofile extends javax.swing.JFrame {


    public Custprofile() {
        initComponents();
        setIconImage(new ImageIcon(getClass().getResource("/img/icon.jpg")).getImage());
        setTitle("New Customer");
        fetch();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        jTextField2 = new javax.swing.JTextField();
        jSeparator2 = new javax.swing.JSeparator();
        jTextField3 = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        jTextField4 = new javax.swing.JTextField();
        label4 = new java.awt.Label();
        jSeparator4 = new javax.swing.JSeparator();
        jTextField5 = new javax.swing.JTextField();
        label5 = new java.awt.Label();
        label6 = new java.awt.Label();
        jSeparator6 = new javax.swing.JSeparator();
        jTextField7 = new javax.swing.JTextField();
        label7 = new java.awt.Label();
        jSeparator7 = new javax.swing.JSeparator();
        jTextField8 = new javax.swing.JTextField();
        label15 = new java.awt.Label();
        label16 = new java.awt.Label();
        jSeparator8 = new javax.swing.JSeparator();
        jTextField9 = new javax.swing.JTextField();
        label17 = new java.awt.Label();
        jSeparator9 = new javax.swing.JSeparator();
        jTextField10 = new javax.swing.JTextField();
        label18 = new java.awt.Label();
        jSeparator10 = new javax.swing.JSeparator();
        jTextField11 = new javax.swing.JTextField();
        label19 = new java.awt.Label();
        jSeparator11 = new javax.swing.JSeparator();
        jTextField12 = new javax.swing.JTextField();
        label20 = new java.awt.Label();
        label23 = new java.awt.Label();
        jLabel13 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        label22 = new java.awt.Label();
        jLabel4 = new javax.swing.JLabel();
        label24 = new java.awt.Label();
        label2 = new java.awt.Label();
        label25 = new java.awt.Label();
        label28 = new java.awt.Label();
        label1 = new java.awt.Label();
        jLabel10 = new javax.swing.JLabel();
        label3 = new java.awt.Label();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        label8 = new java.awt.Label();
        label9 = new java.awt.Label();
        label10 = new java.awt.Label();
        label11 = new java.awt.Label();
        label12 = new java.awt.Label();
        label13 = new java.awt.Label();
        label14 = new java.awt.Label();

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1200, 790));
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setToolTipText("");
        jPanel1.setMinimumSize(new java.awt.Dimension(1400, 500));
        jPanel1.setPreferredSize(new java.awt.Dimension(1400, 800));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 142, 220, 20));

        jTextField2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField2.setBorder(null);
        jPanel1.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 110, 220, 30));

        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 142, 220, 10));

        jTextField3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField3.setBorder(null);
        jPanel1.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 110, 220, 30));

        jSeparator3.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 212, 220, 20));

        jTextField4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField4.setBorder(null);
        jPanel1.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 180, 220, 30));

        label4.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        label4.setForeground(new java.awt.Color(153, 153, 153));
        label4.setText("Contact");
        jPanel1.add(label4, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 146, -1, 50));

        jSeparator4.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 212, 220, 20));

        jTextField5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField5.setBorder(null);
        jPanel1.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 180, 220, 30));

        label5.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        label5.setForeground(new java.awt.Color(153, 153, 153));
        label5.setText("Email");
        jPanel1.add(label5, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 150, -1, 30));

        label6.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        label6.setForeground(new java.awt.Color(153, 153, 153));
        label6.setText("Customer Details");
        jPanel1.add(label6, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 20, -1, -1));

        jSeparator6.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 282, 220, 20));

        jTextField7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField7.setBorder(null);
        jPanel1.add(jTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 250, 220, 30));

        label7.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        label7.setForeground(new java.awt.Color(153, 153, 153));
        label7.setText("Address");
        jPanel1.add(label7, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 216, -1, 50));

        jSeparator7.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(jSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 282, 220, 20));

        jTextField8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField8.setBorder(null);
        jPanel1.add(jTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 250, 220, 30));

        label15.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        label15.setForeground(new java.awt.Color(153, 153, 153));
        label15.setText("Pin Code");
        jPanel1.add(label15, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 230, -1, 20));

        label16.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        label16.setForeground(new java.awt.Color(153, 153, 153));
        label16.setText("Customer Id");
        jPanel1.add(label16, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 76, -1, 50));

        jSeparator8.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(jSeparator8, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 450, 220, -1));

        jTextField9.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField9.setBorder(null);
        jPanel1.add(jTextField9, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 420, 220, 30));

        label17.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        label17.setForeground(new java.awt.Color(153, 153, 153));
        label17.setText("Manufacturer");
        jPanel1.add(label17, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 390, -1, -1));

        jSeparator9.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(jSeparator9, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 450, 220, -1));

        jTextField10.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField10.setBorder(null);
        jPanel1.add(jTextField10, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 420, 220, 30));

        label18.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        label18.setForeground(new java.awt.Color(153, 153, 153));
        label18.setText("Model");
        jPanel1.add(label18, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 390, -1, -1));

        jSeparator10.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(jSeparator10, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 520, 220, -1));

        jTextField11.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField11.setBorder(null);
        jPanel1.add(jTextField11, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 490, 220, 30));

        label19.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        label19.setForeground(new java.awt.Color(153, 153, 153));
        label19.setText("Vehicle Number");
        jPanel1.add(label19, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 460, -1, -1));

        jSeparator11.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(jSeparator11, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 520, 220, -1));

        jTextField12.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField12.setBorder(null);
        jPanel1.add(jTextField12, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 490, 220, 30));

        label20.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        label20.setForeground(new java.awt.Color(153, 153, 153));
        label20.setText("Issues");
        jPanel1.add(label20, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 460, -1, -1));

        label23.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        label23.setForeground(new java.awt.Color(153, 153, 153));
        label23.setText("Vehicle Details");
        jPanel1.add(label23, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 320, -1, -1));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8_Google_Drive_50px.png"))); // NOI18N
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 150, 70, -1));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8_Sync_50px.png"))); // NOI18N
        jLabel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel12MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 260, 70, -1));

        label22.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        label22.setForeground(new java.awt.Color(204, 204, 204));
        label22.setText("Refresh");
        jPanel1.add(label22, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 310, 80, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8_Home_50px.png"))); // NOI18N
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 370, 71, -1));

        label24.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        label24.setForeground(new java.awt.Color(204, 204, 204));
        label24.setText("Home");
        jPanel1.add(label24, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 420, -1, -1));

        label2.setAlignment(java.awt.Label.CENTER);
        label2.setBackground(new java.awt.Color(51, 0, 255));
        label2.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        label2.setForeground(new java.awt.Color(255, 255, 255));
        label2.setText("Update Details");
        label2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                label2MouseClicked(evt);
            }
        });
        jPanel1.add(label2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 560, 300, 60));

        label25.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        label25.setForeground(new java.awt.Color(204, 204, 204));
        label25.setText("Backup");
        jPanel1.add(label25, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 200, -1, -1));

        label28.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        label28.setForeground(new java.awt.Color(153, 153, 153));
        label28.setText("Full Name");
        jPanel1.add(label28, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 76, -1, 50));

        getContentPane().add(jPanel1);
        jPanel1.setBounds(230, 110, 1500, 800);

        label1.setFont(new java.awt.Font("Dialog", 3, 36)); // NOI18N
        label1.setForeground(new java.awt.Color(153, 153, 153));
        label1.setText("VEHICLE MANAGEMENT SYSTEM ");
        getContentPane().add(label1);
        label1.setBounds(310, 10, 602, 51);

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8_Back_To_48px.png"))); // NOI18N
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel10);
        jLabel10.setBounds(20, 30, 60, 50);

        label3.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        label3.setForeground(new java.awt.Color(153, 153, 153));
        label3.setText("A place where you can find Solutons for your vehicle ");
        getContentPane().add(label3);
        label3.setBounds(380, 60, 470, 26);

        jPanel3.setBackground(new java.awt.Color(102, 119, 136));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("New CUStomer");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 220, 40));

        label8.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        label8.setForeground(new java.awt.Color(255, 255, 255));
        label8.setText("About");
        jPanel3.add(label8, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 170, 80, 50));

        label9.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        label9.setForeground(new java.awt.Color(255, 255, 255));
        label9.setText("Purchases");
        jPanel3.add(label9, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 230, 120, 60));

        label10.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        label10.setForeground(new java.awt.Color(255, 255, 255));
        label10.setText("Reports");
        jPanel3.add(label10, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 290, 100, 67));

        label11.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        label11.setForeground(new java.awt.Color(255, 255, 255));
        label11.setText("Accounts");
        jPanel3.add(label11, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 360, 110, 60));

        label12.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        label12.setForeground(new java.awt.Color(255, 255, 255));
        label12.setText("Contact ");
        jPanel3.add(label12, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 110, 100, 50));

        label13.setText("CREDITS");
        jPanel3.add(label13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 470, 197, 30));

        label14.setText("All Copyrights to BRB software solutions");
        jPanel3.add(label14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 500, 220, 30));

        getContentPane().add(jPanel3);
        jPanel3.setBounds(0, 110, 230, 770);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void label2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_label2MouseClicked
try
{
    Class.forName("com.mysql.jdbc.Driver");
    Connection con= (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/vdbms?autoReconnect=true&useSSL=false", "root", "");
    Statement st= (Statement) con.createStatement();

    String cust=jTextField2.getText();
    String name=jTextField3.getText();
    String ct=jTextField4.getText();
    long contact=Long.parseLong(ct);
    String email=jTextField5.getText();
    String address=jTextField7.getText();
    String p=jTextField8.getText();
    long pin=Long.parseLong(p);
    String query="UPDATE `customer` SET `NAME` = ?, `CONTACT` = ?, `EMAIL` = ?, `ADDRESS` =?, `PIN` = ? WHERE `customer`.`CUST_ID` = ? ";
    PreparedStatement psmt=con.prepareStatement(query);
    psmt.setString(1,name );
    psmt.setLong(2, contact);
    psmt.setString(3, email);
    psmt.setString(4, address);
    psmt.setInt(5, (int) pin);
    psmt.setString(6, cust);
    
    psmt.execute();
    String manufacture=jTextField9.getText();
    String model=jTextField10.getText();
    String vehno=jTextField11.getText();
    String issues=jTextField12.getText();
    String query2="UPDATE `vehicle` SET `MANUFACT` = ?, `MODEL` = ?, `VEHICLE_NO` =?, `ISSUES` = ? WHERE `vehicle`.`CUST_ID` = ? ";
    PreparedStatement psmt2=con.prepareStatement(query2);
    psmt2.setString(1, manufacture);
    psmt2.setString(2, model);
    psmt2.setString(3, vehno);
    psmt2.setString(4, issues);
    psmt2.setString(5,cust);
    psmt2.execute();
    JOptionPane.showMessageDialog(null,"Succssfully Updated");
    fetch();
    con.close();
}
catch(Exception e)
{
    JOptionPane.showMessageDialog(null,"Error"+e);
}
        
        
        
                // TODO add your handling code here:
    }//GEN-LAST:event_label2MouseClicked

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        // TODO add your handling code here:
        close();
        Home2 hm2=new Home2();
        hm2.setVisible(true);

       
    }//GEN-LAST:event_jLabel10MouseClicked

    private void jLabel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseClicked
JOptionPane.showMessageDialog(null,"Refresh Done");        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel12MouseClicked

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
close();
Home hm=new Home();
hm.setVisible(true);

        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel4MouseClicked
public void close()
{
    WindowEvent winclosingEvent = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
            Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winclosingEvent);
}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            new Custprofile().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator11;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private java.awt.Label label1;
    private java.awt.Label label10;
    private java.awt.Label label11;
    private java.awt.Label label12;
    private java.awt.Label label13;
    private java.awt.Label label14;
    private java.awt.Label label15;
    private java.awt.Label label16;
    private java.awt.Label label17;
    private java.awt.Label label18;
    private java.awt.Label label19;
    private java.awt.Label label2;
    private java.awt.Label label20;
    private java.awt.Label label22;
    private java.awt.Label label23;
    private java.awt.Label label24;
    private java.awt.Label label25;
    private java.awt.Label label28;
    private java.awt.Label label3;
    private java.awt.Label label4;
    private java.awt.Label label5;
    private java.awt.Label label6;
    private java.awt.Label label7;
    private java.awt.Label label8;
    private java.awt.Label label9;
    // End of variables declaration//GEN-END:variables

    void fetch() {
     try
    {
        FirstPage fp=new FirstPage();
        String key=FirstPage.userid;
        Class.forName("com.mysql.jdbc.Driver");
    Connection con= (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/vdbms?autoReconnect=true&useSSL=false", "root", "");
    Statement st= (Statement) con.createStatement();
    String id = null;
    String n = null;
    long c = 0;
    String e = null;
    String a = null;
    int p = 0;
    
    String query="SELECT * FROM CUSTOMER WHERE CUST_ID=?";
    
    PreparedStatement psmt=con.prepareStatement(query);
        
    psmt.setString(1,key);
    ResultSet rs=psmt.executeQuery();
    while(rs.next())
    {    
        id=rs.getString("CUST_ID");
        n=rs.getString("NAME");
        c=rs.getLong("CONTACT");
        e=rs.getString("EMAIL");
        a=rs.getString("ADDRESS");
        p=rs.getInt("PIN");
        
    }
    String i=String.valueOf(id);
    String cn=String.valueOf(c);
    String pin=String.valueOf(p);
    jTextField2.setText(i);
    jTextField3.setText(n);
    jTextField4.setText(cn);
    jTextField5.setText(e);
    jTextField7.setText(a);
    jTextField8.setText(pin);


    String manufact=null;
    String model=null;
    String vno=null;
    String issues=null;
    
    String query2="SELECT * FROM vehicle WHERE CUST_ID=?";
    PreparedStatement psmt2=con.prepareStatement(query2);
    psmt2.setString(1,key );
    ResultSet rs2=psmt2.executeQuery();
    while(rs2.next())
    {    
        manufact=rs2.getString("MANUFACT");
        model=rs2.getString("MODEL");
        vno=rs2.getString("VEHICLE_NO");
        issues=rs2.getString("ISSUES");
        
        
    }
    
    jTextField9.setText(manufact);
    jTextField10.setText(model);
    jTextField11.setText(vno);
    jTextField12.setText(issues);//To change body of generated methods, choose Tools | Templates.
    }
     catch(Exception e)
     {
         JOptionPane.showMessageDialog(null, e);
     }

 

}
}