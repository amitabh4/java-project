
package javaapplication1;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;


public class Services extends javax.swing.JFrame {

    public Services() {
        initComponents();
        setIconImage(new ImageIcon(getClass().getResource("/img/icon.jpg")).getImage());
        setTitle("Services");
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        label8 = new java.awt.Label();
        label9 = new java.awt.Label();
        label10 = new java.awt.Label();
        label11 = new java.awt.Label();
        label12 = new java.awt.Label();
        label13 = new java.awt.Label();
        label14 = new java.awt.Label();
        label1 = new java.awt.Label();
        label3 = new java.awt.Label();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        label29 = new java.awt.Label();
        label30 = new java.awt.Label();
        label31 = new java.awt.Label();
        label32 = new java.awt.Label();
        label33 = new java.awt.Label();
        label34 = new java.awt.Label();
        label35 = new java.awt.Label();
        jPanel2 = new javax.swing.JPanel();
        label2 = new java.awt.Label();
        jSeparator2 = new javax.swing.JSeparator();
        label4 = new java.awt.Label();
        jTextField2 = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        jTextField3 = new javax.swing.JTextField();
        label5 = new java.awt.Label();
        jSeparator4 = new javax.swing.JSeparator();
        jTextField5 = new javax.swing.JTextField();
        label6 = new java.awt.Label();
        jSeparator6 = new javax.swing.JSeparator();
        label15 = new java.awt.Label();
        label16 = new java.awt.Label();
        jSeparator7 = new javax.swing.JSeparator();
        jTextField8 = new javax.swing.JTextField();
        label18 = new java.awt.Label();
        jSeparator9 = new javax.swing.JSeparator();
        jTextField10 = new javax.swing.JTextField();
        jSeparator10 = new javax.swing.JSeparator();
        jTextField11 = new javax.swing.JTextField();
        label19 = new java.awt.Label();
        jSeparator11 = new javax.swing.JSeparator();
        jTextField12 = new javax.swing.JTextField();
        label20 = new java.awt.Label();
        label22 = new java.awt.Label();
        jSeparator13 = new javax.swing.JSeparator();
        jTextField14 = new javax.swing.JTextField();
        jTextField1 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        label25 = new java.awt.Label();
        label23 = new java.awt.Label();
        jLabel5 = new javax.swing.JLabel();
        label24 = new java.awt.Label();
        jLabel15 = new javax.swing.JLabel();
        label26 = new java.awt.Label();
        jLabel11 = new javax.swing.JLabel();
        label27 = new java.awt.Label();
        jLabel9 = new javax.swing.JLabel();
        label28 = new java.awt.Label();
        jButton1 = new javax.swing.JButton();
        jTextField6 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        jPanel3.setBackground(new java.awt.Color(102, 119, 136));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Welcome");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 140, -1));

        label8.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        label8.setForeground(new java.awt.Color(255, 255, 255));
        label8.setText("About");
        jPanel3.add(label8, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 170, 80, 50));

        label9.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        label9.setForeground(new java.awt.Color(255, 255, 255));
        label9.setText("Purchases");
        jPanel3.add(label9, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 230, 120, 60));

        label10.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        label10.setForeground(new java.awt.Color(255, 255, 255));
        label10.setText("Reports");
        jPanel3.add(label10, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 290, 100, 67));

        label11.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        label11.setForeground(new java.awt.Color(255, 255, 255));
        label11.setText("Accounts");
        jPanel3.add(label11, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 360, 110, 60));

        label12.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        label12.setForeground(new java.awt.Color(255, 255, 255));
        label12.setText("Contact ");
        jPanel3.add(label12, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 110, 100, 50));

        label13.setText("CREDITS");
        jPanel3.add(label13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 470, 197, 30));

        label14.setText("All Copyrights to RRB software solutions");
        jPanel3.add(label14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 500, 220, 30));

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1200, 790));
        getContentPane().setLayout(null);

        label1.setFont(new java.awt.Font("Dialog", 3, 36)); // NOI18N
        label1.setForeground(new java.awt.Color(153, 153, 153));
        label1.setText("VEHICLE MANAGEMENT SYSTEM ");
        getContentPane().add(label1);
        label1.setBounds(310, 10, 602, 51);

        label3.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        label3.setForeground(new java.awt.Color(153, 153, 153));
        label3.setText("A place where you can find Solutons for your vehicle ");
        getContentPane().add(label3);
        label3.setBounds(380, 60, 500, 26);

        jPanel5.setBackground(new java.awt.Color(102, 119, 136));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Tahoma", 3, 32)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Services");
        jPanel5.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 160, -1));

        label29.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        label29.setForeground(new java.awt.Color(255, 255, 255));
        label29.setText("About");
        jPanel5.add(label29, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 170, 80, 50));

        label30.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        label30.setForeground(new java.awt.Color(255, 255, 255));
        label30.setText("Purchases");
        jPanel5.add(label30, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 230, 120, 60));

        label31.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        label31.setForeground(new java.awt.Color(255, 255, 255));
        label31.setText("Reports");
        jPanel5.add(label31, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 290, 100, 67));

        label32.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        label32.setForeground(new java.awt.Color(255, 255, 255));
        label32.setText("Accounts");
        jPanel5.add(label32, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 360, 110, 60));

        label33.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        label33.setForeground(new java.awt.Color(255, 255, 255));
        label33.setText("Contact ");
        jPanel5.add(label33, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 110, 100, 50));

        label34.setText("CREDITS");
        jPanel5.add(label34, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 470, 197, 30));

        label35.setText("All Copyrights to RRB software solutions");
        jPanel5.add(label35, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 500, 220, 30));

        getContentPane().add(jPanel5);
        jPanel5.setBounds(0, 110, 230, 770);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label2.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        label2.setText("Update Service Table");
        jPanel2.add(label2, new org.netbeans.lib.awtextra.AbsoluteConstraints(31, 23, -1, -1));

        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 140, 230, 10));

        label4.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        label4.setForeground(new java.awt.Color(153, 153, 153));
        label4.setText("Service No:");
        jPanel2.add(label4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 80, -1, -1));

        jTextField2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField2.setBorder(null);
        jPanel2.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 110, 230, 30));

        jSeparator3.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 140, 230, 10));

        jTextField3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField3.setBorder(null);
        jPanel2.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 110, 230, 30));

        label5.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        label5.setForeground(new java.awt.Color(153, 153, 153));
        label5.setText("Vehicle No:");
        jPanel2.add(label5, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 80, -1, -1));

        jSeparator4.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 220, 230, 10));

        jTextField5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField5.setBorder(null);
        jPanel2.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 270, 180, 30));

        label6.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        label6.setForeground(new java.awt.Color(153, 153, 153));
        label6.setText("Customer Id:");
        jPanel2.add(label6, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 160, -1, -1));

        jSeparator6.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 300, 180, 10));

        label15.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        label15.setForeground(new java.awt.Color(153, 153, 153));
        label15.setText("Service Date:");
        jPanel2.add(label15, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 240, -1, -1));

        label16.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        label16.setForeground(new java.awt.Color(153, 153, 153));
        label16.setText("Issues:");
        jPanel2.add(label16, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 160, -1, -1));

        jSeparator7.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.add(jSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 220, 230, 10));

        jTextField8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField8.setBorder(null);
        jPanel2.add(jTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 190, 230, 30));

        label18.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        label18.setForeground(new java.awt.Color(153, 153, 153));
        label18.setText("Warrenty Duration:");
        jPanel2.add(label18, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 240, -1, -1));

        jSeparator9.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.add(jSeparator9, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 300, 230, 10));

        jTextField10.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField10.setBorder(null);
        jPanel2.add(jTextField10, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 270, 230, 30));

        jSeparator10.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.add(jSeparator10, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 370, 230, 10));

        jTextField11.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField11.setBorder(null);
        jTextField11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField11ActionPerformed(evt);
            }
        });
        jPanel2.add(jTextField11, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 340, 230, 30));

        label19.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        label19.setForeground(new java.awt.Color(153, 153, 153));
        label19.setText("Offer No(Optional):");
        jPanel2.add(label19, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 310, -1, -1));

        jSeparator11.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.add(jSeparator11, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 450, 160, 10));

        jTextField12.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField12.setBorder(null);
        jPanel2.add(jTextField12, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 420, 160, 30));

        label20.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        label20.setForeground(new java.awt.Color(153, 153, 153));
        label20.setText("Total Price");
        jPanel2.add(label20, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 390, -1, -1));

        label22.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        label22.setForeground(new java.awt.Color(153, 153, 153));
        label22.setText("GST:");
        jPanel2.add(label22, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 320, -1, -1));

        jSeparator13.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.add(jSeparator13, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 380, 120, 10));

        jTextField14.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField14.setBorder(null);
        jPanel2.add(jTextField14, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 350, 120, 30));
        jPanel2.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 20, 190, 30));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8_Search_52px.png"))); // NOI18N
        jLabel4.setText("jLabel4");
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 10, 50, 60));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8_Sync_50px.png"))); // NOI18N
        jLabel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel12MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 260, 70, -1));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8_Google_Drive_50px.png"))); // NOI18N
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 150, 70, -1));

        label25.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        label25.setForeground(new java.awt.Color(204, 204, 204));
        label25.setText("Backup");
        jPanel2.add(label25, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 200, -1, -1));

        label23.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        label23.setForeground(new java.awt.Color(204, 204, 204));
        label23.setText("Refresh");
        jPanel2.add(label23, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 310, 80, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8_Home_50px.png"))); // NOI18N
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 370, 71, -1));

        label24.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        label24.setForeground(new java.awt.Color(204, 204, 204));
        label24.setText("Home");
        jPanel2.add(label24, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 420, -1, -1));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8_Clear_Symbol_48px_1.png"))); // NOI18N
        jLabel15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel15MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 140, 60, 60));

        label26.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        label26.setForeground(new java.awt.Color(204, 204, 204));
        label26.setText("Update");
        jPanel2.add(label26, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 200, -1, -1));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8_Delete_48px_1.png"))); // NOI18N
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 260, 60, 50));

        label27.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        label27.setForeground(new java.awt.Color(204, 204, 204));
        label27.setText("Delete");
        jPanel2.add(label27, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 310, -1, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8_View_48px_1.png"))); // NOI18N
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 360, 60, 70));

        label28.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        label28.setForeground(new java.awt.Color(204, 204, 204));
        label28.setText("View All");
        jPanel2.add(label28, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 420, -1, 30));

        jButton1.setBackground(new java.awt.Color(0, 0, 255));
        jButton1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Save Data");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 490, 290, 60));

        jTextField6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField6.setBorder(null);
        jPanel2.add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 190, 230, 30));

        getContentPane().add(jPanel2);
        jPanel2.setBounds(230, 110, 970, 680);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8_Back_To_48px.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel2);
        jLabel2.setBounds(20, 30, 50, 50);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
close();
Home hm=new Home();
hm.setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        close();
        Home hm=new Home();
        hm.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseClicked
        JOptionPane.showMessageDialog(null,"Refresh Done");        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel12MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
try
{
    Class.forName("com.mysql.jdbc.Driver");
    Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/vdbms?autoReconnect=true&useSSL=false", "root", "");
    String sevno=jTextField2.getText();
    String vehno=jTextField3.getText();
    String cusid=jTextField6.getText();
    String servdate=jTextField5.getText();
    String issues=jTextField8.getText();
    String wardr=jTextField10.getText();
    int wd=Integer.parseInt(wardr);
    String gstt=jTextField14.getText();
    int gst=Integer.parseInt(gstt);
    String offno2=jTextField11.getText();
    int offno=Integer.parseInt(offno2);
    String tot =jTextField12.getText();
    Long totprice=Long.parseLong(tot);
    String query="INSERT INTO SERVICES(SERV_NO,VEHICLE_NO,CUST_ID,ISSUES,SER_DATE,WAR_DURA,GST,OFF_NO,TOT_PRICE)"+"VALUES(?,?,?,?,?,?,?,?,?)";
    PreparedStatement pmst=con.prepareStatement(query);
    pmst.setString(1, sevno);
    pmst.setString(2, vehno);
    pmst.setString(3, cusid);
    pmst.setString(4, issues);
    pmst.setString(5, servdate);
    pmst.setInt(6, wd);
    pmst.setInt(7, gst);
    pmst.setInt(8, offno);
    pmst.setLong(9, totprice);
    pmst.execute();
    JOptionPane.showMessageDialog(null, "Data Saved Successfully");
    jTextField2.setText(null);
    jTextField3.setText(null);
    jTextField14.setText(null);
    jTextField5.setText(null);
    jTextField6.setText(null);
    jTextField8.setText(null);
    jTextField10.setText(null);
    jTextField11.setText(null);
    jTextField12.setText(null);
    jTextField14.setText(null);
}
catch(Exception e)
{
    JOptionPane.showMessageDialog(null, e);
}// TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTextField11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField11ActionPerformed

    private void jLabel15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel15MouseClicked
try
{
    Class.forName("com.mysql.jdbc.Driver");
    Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/vdbms?autoReconnect=true&useSSL=false", "root", "");
    String sevno=jTextField2.getText();
    String vehno=jTextField3.getText();
    String cusid=jTextField6.getText();
    String servdate=jTextField5.getText();
    String issues=jTextField8.getText();
    String wardr=jTextField10.getText();
    int wd=Integer.parseInt(wardr);
    String gstt=jTextField14.getText();
    int gst=Integer.parseInt(gstt);
    String offno2=jTextField11.getText();
    int offno=Integer.parseInt(offno2);
    String tot =jTextField12.getText();
    Long totprice=Long.parseLong(tot);
    String query="UPDATE `services` SET `VEHICLE_NO` = ?, `CUST_ID` = ?, `ISSUES` = ?, `SER_DATE` = ?, `WAR_DURA` = ?, `GST` = ?, `OFF_NO` = ?, `TOT_PRICE` =?  WHERE `services`.`SERV_NO` = ?";
    PreparedStatement pmst=con.prepareStatement(query);
    pmst.setString(1, vehno);
    pmst.setString(2, cusid);
    pmst.setString(3, issues);
    pmst.setString(4, servdate);
    pmst.setInt(5, wd);
    pmst.setInt(6, gst);
    pmst.setInt(7, offno);
    pmst.setLong(8, totprice);
    pmst.setString(9, sevno);
    pmst.execute();
    JOptionPane.showMessageDialog(null, "Updated Successfully");
    jTextField2.setText(null);
    jTextField3.setText(null);
    jTextField14.setText(null);
    jTextField5.setText(null);
    jTextField6.setText(null);
    jTextField8.setText(null);
    jTextField10.setText(null);
    jTextField11.setText(null);
    jTextField12.setText(null);
    jTextField14.setText(null);
}
catch(Exception e)
{
    JOptionPane.showMessageDialog(null, e);
}        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel15MouseClicked

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
 try
    {
        Class.forName("com.mysql.jdbc.Driver");
    Connection con= (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/vdbms?autoReconnect=true&useSSL=false", "root", "");
    Statement st= (Statement) con.createStatement();
    String servno = null;
    String vhno = null;
    String custid = null;
    String issues = null;
    String date = null;
    int wardura = 0;
    int offno=0;
    int gst = 0;
    long tot=0;
    String key=jTextField1.getText();
    
    String query="SELECT * FROM services WHERE SERV_NO=?";
    PreparedStatement psmt=con.prepareStatement(query);
    psmt.setString(1,key );
    ResultSet rs=psmt.executeQuery();
    while(rs.next())
    {    
        servno=rs.getString("SERV_NO");
        vhno=rs.getString("VEHICLE_NO");
        custid=rs.getString("CUST_ID");
        issues=rs.getString("ISSUES");
        date=rs.getString("SER_DATE");
        wardura=rs.getInt("WAR_DURA");
        gst=rs.getInt("GST");
        offno=rs.getInt("OFF_NO");
        tot=rs.getLong("TOT_PRICE");
    }
    if(servno==null)
    {
        JOptionPane.showMessageDialog(null,"NO Record");
        
jTextField2.setText(null);
jTextField3.setText(null);
jTextField6.setText(null);
jTextField8.setText(null);
jTextField5.setText(null);
jTextField10.setText(null);
jTextField14.setText(null);
jTextField11.setText(null);
jTextField12.setText(null);
    }
    else
    {
    String i=String.valueOf(wardura);
    String cn=String.valueOf(gst);
    String pin=String.valueOf(offno);
    String amt=String.valueOf(tot);
    jTextField2.setText(servno);
jTextField3.setText(vhno);
jTextField6.setText(custid);
jTextField8.setText(issues);
jTextField5.setText(date);
jTextField10.setText(i);
jTextField14.setText(cn);
jTextField11.setText(pin);
jTextField12.setText(amt);
    
    
    }
    con.close();
    
   }
    catch(Exception e)
    {
        JOptionPane.showMessageDialog(null,"error"+e);
    }        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
try
{
   Class.forName("com.mysql.jdbc.Driver");
    Connection con= (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/vdbms?autoReconnect=true&useSSL=false", "root", "");
    String st=JOptionPane.showInputDialog("Enter The Service No");
    String query="delete from services where SERV_NO=?";
    PreparedStatement psmt=con.prepareStatement(query);
    psmt.setString(1,st );
    psmt.execute();
    
        JOptionPane.showMessageDialog(null,"Deleted Successfully");
       
    
    
}
catch(Exception e)
{
    JOptionPane.showMessageDialog(null,"Invalid Service No");
}
    }//GEN-LAST:event_jLabel11MouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
ViewServices vs=new ViewServices();
vs.setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_jLabel9MouseClicked
public void close()
{
    WindowEvent winclosingEvent = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
            Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winclosingEvent);
}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Services.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Services.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Services.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Services.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Services().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator11;
    private javax.swing.JSeparator jSeparator13;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField8;
    private java.awt.Label label1;
    private java.awt.Label label10;
    private java.awt.Label label11;
    private java.awt.Label label12;
    private java.awt.Label label13;
    private java.awt.Label label14;
    private java.awt.Label label15;
    private java.awt.Label label16;
    private java.awt.Label label18;
    private java.awt.Label label19;
    private java.awt.Label label2;
    private java.awt.Label label20;
    private java.awt.Label label22;
    private java.awt.Label label23;
    private java.awt.Label label24;
    private java.awt.Label label25;
    private java.awt.Label label26;
    private java.awt.Label label27;
    private java.awt.Label label28;
    private java.awt.Label label29;
    private java.awt.Label label3;
    private java.awt.Label label30;
    private java.awt.Label label31;
    private java.awt.Label label32;
    private java.awt.Label label33;
    private java.awt.Label label34;
    private java.awt.Label label35;
    private java.awt.Label label4;
    private java.awt.Label label5;
    private java.awt.Label label6;
    private java.awt.Label label8;
    private java.awt.Label label9;
    // End of variables declaration//GEN-END:variables

}
