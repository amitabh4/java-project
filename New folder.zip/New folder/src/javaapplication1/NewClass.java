


package javaapplication1;

import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class NewClass {
    
    JFrame f1=new JFrame();
    JPanel jp1=new JPanel();
    JPanel jp2=new JPanel();
    NewClass()
    {
        f1.setLayout(null);
        jp1.setBounds(0, 0, 1002, 620);
        jp1.setBackground(Color.white);
        jp2.setBounds(0, 0, 300, 620);
        jp2.setBackground(Color.magenta);
        f1.setSize(1002, 620);
        f1.add(jp2);
        f1.add(jp1);
        f1.setVisible(true);
    }
    public static void main(String args[])
    {
        NewClass nc=new NewClass();
    }
    
}
